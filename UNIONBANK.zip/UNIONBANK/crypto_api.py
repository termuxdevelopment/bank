import requests
import logging
from datetime import datetime, timedelta

def get_crypto_prices():
    """Fetch current cryptocurrency prices from CoinGecko API"""
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': 'bitcoin,ethereum,tether,binancecoin,cardano,solana,polkadot,dogecoin,avalanche-2,polygon',
            'vs_currencies': 'usd',
            'include_24hr_change': 'true'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Map the API response to our format
        crypto_map = {
            'bitcoin': {'name': 'Bitcoin', 'symbol': 'BTC'},
            'ethereum': {'name': 'Ethereum', 'symbol': 'ETH'},
            'tether': {'name': 'Tether', 'symbol': 'USDT'},
            'binancecoin': {'name': 'Binance Coin', 'symbol': 'BNB'},
            'cardano': {'name': 'Cardano', 'symbol': 'ADA'},
            'solana': {'name': 'Solana', 'symbol': 'SOL'},
            'polkadot': {'name': 'Polkadot', 'symbol': 'DOT'},
            'dogecoin': {'name': 'Dogecoin', 'symbol': 'DOGE'},
            'avalanche-2': {'name': 'Avalanche', 'symbol': 'AVAX'},
            'polygon': {'name': 'Polygon', 'symbol': 'MATIC'}
        }
        
        formatted_data = {}
        for crypto_id, crypto_data in data.items():
            if crypto_id in crypto_map:
                symbol = crypto_map[crypto_id]['symbol']
                formatted_data[symbol] = {
                    'name': crypto_map[crypto_id]['name'],
                    'price': crypto_data['usd'],
                    'change_24h': crypto_data.get('usd_24h_change', 0)
                }
        
        return formatted_data
        
    except Exception as e:
        logging.error(f"Error fetching crypto prices: {e}")
        # Return fallback data
        return {
            'BTC': {'name': 'Bitcoin', 'price': 0, 'change_24h': 0},
            'ETH': {'name': 'Ethereum', 'price': 0, 'change_24h': 0},
            'USDT': {'name': 'Tether', 'price': 0, 'change_24h': 0},
            'BNB': {'name': 'Binance Coin', 'price': 0, 'change_24h': 0},
        }

def get_crypto_chart_data(symbol):
    """Fetch chart data for a specific cryptocurrency"""
    try:
        # Map symbols to CoinGecko IDs
        symbol_map = {
            'BTC': 'bitcoin',
            'ETH': 'ethereum',
            'USDT': 'tether',
            'BNB': 'binancecoin',
            'ADA': 'cardano',
            'SOL': 'solana',
            'DOT': 'polkadot',
            'DOGE': 'dogecoin',
            'AVAX': 'avalanche-2',
            'MATIC': 'polygon'
        }
        
        crypto_id = symbol_map.get(symbol.upper())
        if not crypto_id:
            return []
        
        url = f"https://api.coingecko.com/api/v3/coins/{crypto_id}/market_chart"
        params = {
            'vs_currency': 'usd',
            'days': '7',  # Last 7 days
            'interval': 'daily'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Format data for Chart.js
        chart_data = []
        for price_point in data.get('prices', []):
            timestamp = price_point[0]
            price = price_point[1]
            date = datetime.fromtimestamp(timestamp / 1000).strftime('%Y-%m-%d')
            chart_data.append({'date': date, 'price': price})
        
        return chart_data
        
    except Exception as e:
        logging.error(f"Error fetching chart data for {symbol}: {e}")
        return []
