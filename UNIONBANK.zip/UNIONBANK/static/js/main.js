// UnionBank - Main JavaScript Functions
(function() {
    'use strict';

    // DOM Ready
    document.addEventListener('DOMContentLoaded', function() {
        initializeApp();
    });

    function initializeApp() {
        initTheme();
        initAnimations();
        initCardInteractions();
        initFormValidation();
        initTooltips();
        initCopyFunctionality();
        initMobileMenu();
        initAutoRefresh();
    }

    // Theme Management
    function initTheme() {
        const themeToggle = document.querySelector('#theme-toggle');
        const currentTheme = localStorage.getItem('theme') || 'dark';
        
        // Apply saved theme
        document.body.className = `theme-${currentTheme}`;
        
        if (themeToggle) {
            themeToggle.addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-light') ? 'light' : 'dark';
                const newTheme = currentTheme === 'light' ? 'dark' : 'light';
                
                document.body.className = `theme-${newTheme}`;
                localStorage.setItem('theme', newTheme);
                
                // Update theme in user settings if logged in
                updateUserTheme(newTheme);
            });
        }
    }

    function updateUserTheme(theme) {
        fetch('/api/update-theme', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken()
            },
            body: JSON.stringify({ theme: theme })
        }).catch(err => console.log('Theme update failed:', err));
    }

    // Animations
    function initAnimations() {
        // Fade in elements on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        // Observe elements for animation
        document.querySelectorAll('.card, .feature-card, .crypto-card').forEach(el => {
            observer.observe(el);
        });

        // Card hover effects
        document.querySelectorAll('.virtual-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'rotateY(5deg) rotateX(5deg) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'rotateY(0deg) rotateX(0deg) scale(1)';
            });
        });
    }

    // Card Interactions
    function initCardInteractions() {
        // Virtual card flip animation
        const virtualCards = document.querySelectorAll('.virtual-card');
        
        virtualCards.forEach(card => {
            card.addEventListener('click', function() {
                if (!this.classList.contains('flipped')) {
                    this.style.transform = 'rotateY(180deg)';
                    this.classList.add('flipped');
                    
                    setTimeout(() => {
                        this.style.transform = 'rotateY(0deg)';
                        this.classList.remove('flipped');
                    }, 2000);
                }
            });
        });

        // Card number formatting
        const cardNumberInputs = document.querySelectorAll('input[name="card_number"]');
        cardNumberInputs.forEach(input => {
            input.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                value = value.replace(/(\d{4})(?=\d)/g, '$1-');
                this.value = value;
            });
        });

        // Copy card details
        document.querySelectorAll('[data-copy]').forEach(element => {
            element.addEventListener('click', function() {
                const textToCopy = this.getAttribute('data-copy');
                copyToClipboard(textToCopy);
                showToast('Copied to clipboard!', 'success');
            });
        });
    }

    // Form Validation
    function initFormValidation() {
        const forms = document.querySelectorAll('form');
        
        forms.forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!validateForm(this)) {
                    e.preventDefault();
                    return false;
                }
                
                // Add loading state
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
                }
            });
        });

        // Real-time validation
        document.querySelectorAll('input[required]').forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
        });

        // Password strength indicator
        const passwordInputs = document.querySelectorAll('input[type="password"]');
        passwordInputs.forEach(input => {
            if (input.name === 'password') {
                input.addEventListener('input', function() {
                    showPasswordStrength(this);
                });
            }
        });
    }

    function validateForm(form) {
        let isValid = true;
        const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
        
        requiredFields.forEach(field => {
            if (!validateField(field)) {
                isValid = false;
            }
        });
        
        return isValid;
    }

    function validateField(field) {
        const value = field.value.trim();
        const fieldType = field.type;
        const fieldName = field.name;
        let isValid = true;
        let errorMessage = '';

        // Remove existing error styling
        field.classList.remove('is-invalid');
        const existingError = field.parentNode.querySelector('.invalid-feedback');
        if (existingError) {
            existingError.remove();
        }

        // Required field validation
        if (field.hasAttribute('required') && !value) {
            isValid = false;
            errorMessage = 'This field is required';
        }
        
        // Email validation
        else if (fieldType === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }
        }
        
        // Password validation
        else if (fieldName === 'password' && value) {
            if (value.length < 6) {
                isValid = false;
                errorMessage = 'Password must be at least 6 characters long';
            }
        }
        
        // Password confirmation
        else if (fieldName === 'password2' && value) {
            const password = form.querySelector('input[name="password"]');
            if (password && value !== password.value) {
                isValid = false;
                errorMessage = 'Passwords do not match';
            }
        }
        
        // Amount validation
        else if (fieldName === 'amount' && value) {
            const amount = parseFloat(value);
            if (isNaN(amount) || amount <= 0) {
                isValid = false;
                errorMessage = 'Please enter a valid amount';
            }
        }

        // Show error if validation failed
        if (!isValid) {
            field.classList.add('is-invalid');
            const errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            errorDiv.textContent = errorMessage;
            field.parentNode.appendChild(errorDiv);
        }

        return isValid;
    }

    function showPasswordStrength(passwordInput) {
        const password = passwordInput.value;
        let strength = 0;
        let strengthText = '';
        let strengthClass = '';

        // Remove existing strength indicator
        const existingIndicator = passwordInput.parentNode.querySelector('.password-strength');
        if (existingIndicator) {
            existingIndicator.remove();
        }

        if (password.length >= 6) strength++;
        if (password.match(/[a-z]/)) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^a-zA-Z0-9]/)) strength++;

        switch (strength) {
            case 0:
            case 1:
                strengthText = 'Very Weak';
                strengthClass = 'text-danger';
                break;
            case 2:
                strengthText = 'Weak';
                strengthClass = 'text-warning';
                break;
            case 3:
                strengthText = 'Fair';
                strengthClass = 'text-info';
                break;
            case 4:
                strengthText = 'Good';
                strengthClass = 'text-success';
                break;
            case 5:
                strengthText = 'Strong';
                strengthClass = 'text-success fw-bold';
                break;
        }

        if (password.length > 0) {
            const strengthDiv = document.createElement('div');
            strengthDiv.className = `password-strength small ${strengthClass}`;
            strengthDiv.textContent = `Password strength: ${strengthText}`;
            passwordInput.parentNode.appendChild(strengthDiv);
        }
    }

    // Tooltips
    function initTooltips() {
        // Initialize Bootstrap tooltips if available
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }

        // Custom tooltips for card details
        document.querySelectorAll('.card-number, .card-cvv').forEach(element => {
            element.addEventListener('mouseenter', function() {
                showTooltip(this, 'Click to copy');
            });
        });
    }

    function showTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'custom-tooltip';
        tooltip.textContent = text;
        tooltip.style.cssText = `
            position: absolute;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            z-index: 1000;
            pointer-events: none;
        `;
        
        document.body.appendChild(tooltip);
        
        const rect = element.getBoundingClientRect();
        tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
        tooltip.style.top = rect.top - tooltip.offsetHeight - 5 + 'px';
        
        setTimeout(() => {
            if (tooltip.parentNode) {
                tooltip.parentNode.removeChild(tooltip);
            }
        }, 2000);
    }

    // Copy Functionality
    function initCopyFunctionality() {
        document.querySelectorAll('[data-copy-target]').forEach(button => {
            button.addEventListener('click', function() {
                const targetSelector = this.getAttribute('data-copy-target');
                const targetElement = document.querySelector(targetSelector);
                
                if (targetElement) {
                    const textToCopy = targetElement.textContent || targetElement.value;
                    copyToClipboard(textToCopy);
                }
            });
        });
    }

    function copyToClipboard(text) {
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(() => {
                showToast('Copied to clipboard!', 'success');
            }).catch(err => {
                console.error('Failed to copy:', err);
                fallbackCopyTextToClipboard(text);
            });
        } else {
            fallbackCopyTextToClipboard(text);
        }
    }

    function fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showToast('Copied to clipboard!', 'success');
        } catch (err) {
            console.error('Fallback: Oops, unable to copy', err);
            showToast('Failed to copy to clipboard', 'error');
        }
        
        document.body.removeChild(textArea);
    }

    // Toast Notifications
    function showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast-notification toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${getToastIcon(type)} me-2"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            z-index: 9999;
            min-width: 300px;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 300);
            }
        }, duration);
    }

    function getToastIcon(type) {
        switch (type) {
            case 'success': return 'check-circle';
            case 'error': return 'exclamation-circle';
            case 'warning': return 'exclamation-triangle';
            default: return 'info-circle';
        }
    }

    // Mobile Menu
    function initMobileMenu() {
        const mobileMenuToggle = document.querySelector('.navbar-toggler');
        const mobileMenu = document.querySelector('.navbar-collapse');
        
        if (mobileMenuToggle && mobileMenu) {
            mobileMenuToggle.addEventListener('click', function() {
                mobileMenu.classList.toggle('show');
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', function(e) {
                if (!mobileMenuToggle.contains(e.target) && !mobileMenu.contains(e.target)) {
                    mobileMenu.classList.remove('show');
                }
            });
        }
    }

    // Auto Refresh for Crypto Prices
    function initAutoRefresh() {
        const cryptoPage = document.querySelector('[data-page="crypto"]');
        if (cryptoPage) {
            setInterval(() => {
                refreshCryptoPrices();
            }, 60000); // Refresh every minute
        }
    }

    function refreshCryptoPrices() {
        fetch('/api/crypto-prices')
            .then(response => response.json())
            .then(data => {
                updateCryptoPrices(data);
            })
            .catch(err => console.log('Failed to refresh crypto prices:', err));
    }

    function updateCryptoPrices(prices) {
        Object.keys(prices).forEach(symbol => {
            const priceElement = document.querySelector(`[data-crypto="${symbol}"] .crypto-price h3`);
            const changeElement = document.querySelector(`[data-crypto="${symbol}"] .crypto-price small`);
            
            if (priceElement) {
                priceElement.textContent = `$${prices[symbol].price.toFixed(2)}`;
            }
            
            if (changeElement && prices[symbol].change_24h !== undefined) {
                const change = prices[symbol].change_24h;
                changeElement.className = change >= 0 ? 'text-success' : 'text-danger';
                changeElement.innerHTML = `
                    <i class="fas fa-arrow-${change >= 0 ? 'up' : 'down'} me-1"></i>
                    ${Math.abs(change).toFixed(2)}%
                `;
            }
        });
    }

    // Utility Functions
    function getCSRFToken() {
        const token = document.querySelector('meta[name="csrf-token"]');
        return token ? token.getAttribute('content') : '';
    }

    function formatCurrency(amount, currency = 'USD') {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency
        }).format(amount);
    }

    function formatDate(date) {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(new Date(date));
    }

    // Loading States
    function showLoading(element) {
        element.classList.add('loading');
        element.style.pointerEvents = 'none';
    }

    function hideLoading(element) {
        element.classList.remove('loading');
        element.style.pointerEvents = 'auto';
    }

    // Form Submission with AJAX
    function submitFormAjax(form, successCallback, errorCallback) {
        const formData = new FormData(form);
        const url = form.action || window.location.href;
        
        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': getCSRFToken()
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (successCallback) {
                successCallback(data);
            }
        })
        .catch(error => {
            if (errorCallback) {
                errorCallback(error);
            } else {
                showToast('An error occurred. Please try again.', 'error');
            }
        });
    }

    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        .toast-notification {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .toast-content {
            display: flex;
            align-items: center;
        }
        
        .toast-close {
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 0;
            margin-left: 1rem;
        }
        
        .toast-close:hover {
            color: var(--text-primary);
        }
        
        .toast-success {
            border-left: 4px solid var(--success-color);
        }
        
        .toast-error {
            border-left: 4px solid var(--danger-color);
        }
        
        .toast-warning {
            border-left: 4px solid var(--warning-color);
        }
        
        .toast-info {
            border-left: 4px solid var(--info-color);
        }
    `;
    document.head.appendChild(style);

    // Expose utility functions globally
    window.UnionBank = {
        showToast,
        copyToClipboard,
        formatCurrency,
        formatDate,
        showLoading,
        hideLoading,
        submitFormAjax
    };

})();
