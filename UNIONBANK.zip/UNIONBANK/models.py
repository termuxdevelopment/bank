from app import db
from flask_login import UserMixin
from datetime import datetime
import secrets
import string

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    language = db.Column(db.String(2), default='ru')  # ru or en
    theme = db.Column(db.String(10), default='dark')  # light or dark
    crypto_wallet = db.Column(db.String(256), default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_blocked = db.Column(db.Boolean, default=False)
    
    # Relationship with virtual cards
    cards = db.relationship('VirtualCard', backref='owner', lazy=True, cascade='all, delete-orphan')

class VirtualCard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    card_number = db.Column(db.String(19), unique=True, nullable=False)  # Format: 4000-1234-5678-9012
    cvv = db.Column(db.String(3), nullable=False)
    expiry_month = db.Column(db.String(2), nullable=False)
    expiry_year = db.Column(db.String(2), nullable=False)
    balance = db.Column(db.Float, default=0.0)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_blocked = db.Column(db.Boolean, default=False)
    
    def __init__(self, user_id):
        self.user_id = user_id
        self.card_number = self.generate_card_number()
        self.cvv = self.generate_cvv()
        self.expiry_month = "12"
        self.expiry_year = "29"
    
    def generate_card_number(self):
        """Generate a unique virtual card number"""
        while True:
            # Generate card number with format 4000-XXXX-XXXX-XXXX
            number = "4000-" + "-".join([
                ''.join(secrets.choice(string.digits) for _ in range(4)) for _ in range(3)
            ])
            # Check if number already exists
            existing = VirtualCard.query.filter_by(card_number=number).first()
            if not existing:
                return number
    
    def generate_cvv(self):
        """Generate a 3-digit CVV"""
        return ''.join(secrets.choice(string.digits) for _ in range(3))

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    card_id = db.Column(db.Integer, db.ForeignKey('virtual_card.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # 'deposit', 'withdrawal', 'purchase'
    description = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    admin_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    
    card = db.relationship('VirtualCard', backref='transactions')
    admin = db.relationship('User', foreign_keys=[admin_id])

class SupportMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    responded_at = db.Column(db.DateTime)
    is_resolved = db.Column(db.Boolean, default=False)
    
    user = db.relationship('User', backref='support_messages')
