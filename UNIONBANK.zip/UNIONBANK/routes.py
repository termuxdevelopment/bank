from flask import render_template, flash, redirect, url_for, request, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, db
from models import User, VirtualCard, Transaction, SupportMessage
from forms import LoginForm, RegistrationForm, AdminAddFundsForm, AdminBlockCardForm, AdminUnblockCardForm, SettingsForm, SupportForm
from utils import get_translations
from crypto_api import get_crypto_prices, get_crypto_chart_data
import logging

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html', translations=get_translations(session.get('language', 'ru')))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            if user.is_blocked:
                flash('Your account has been blocked. Please contact support.', 'error')
                return render_template('login.html', form=form, translations=get_translations(session.get('language', 'ru')))
            
            login_user(user)
            session['language'] = user.language
            session['theme'] = user.theme
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        flash('Invalid username or password', 'error')
    
    return render_template('login.html', form=form, translations=get_translations(session.get('language', 'ru')))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check if username exists
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists', 'error')
            return render_template('register.html', form=form, translations=get_translations(session.get('language', 'ru')))
        
        # Check if email exists
        existing_email = User.query.filter_by(email=form.email.data).first()
        if existing_email:
            flash('Email already registered', 'error')
            return render_template('register.html', form=form, translations=get_translations(session.get('language', 'ru')))
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=generate_password_hash(form.password.data)
        )
        db.session.add(user)
        db.session.commit()
        
        # Create virtual card for new user
        card = VirtualCard(user_id=user.id)
        db.session.add(card)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form, translations=get_translations(session.get('language', 'ru')))

@app.route('/dashboard')
@login_required
def dashboard():
    card = VirtualCard.query.filter_by(user_id=current_user.id).first()
    if not card:
        # Create card if user doesn't have one
        card = VirtualCard(user_id=current_user.id)
        db.session.add(card)
        db.session.commit()
    
    recent_transactions = Transaction.query.filter_by(card_id=card.id).order_by(Transaction.created_at.desc()).limit(5).all()
    
    return render_template('dashboard.html', 
                         card=card, 
                         transactions=recent_transactions,
                         translations=get_translations(current_user.language))

@app.route('/crypto')
@login_required
def crypto():
    try:
        prices = get_crypto_prices()
        return render_template('crypto.html', 
                             prices=prices, 
                             translations=get_translations(current_user.language))
    except Exception as e:
        logging.error(f"Error fetching crypto prices: {e}")
        flash('Unable to fetch cryptocurrency prices at the moment.', 'error')
        return render_template('crypto.html', 
                             prices={}, 
                             translations=get_translations(current_user.language))

@app.route('/crypto/<symbol>')
@login_required
def crypto_detail(symbol):
    try:
        prices = get_crypto_prices()
        chart_data = get_crypto_chart_data(symbol)
        crypto_info = prices.get(symbol.upper(), {})
        
        return render_template('crypto_detail.html', 
                             symbol=symbol.upper(),
                             crypto_info=crypto_info,
                             chart_data=chart_data,
                             translations=get_translations(current_user.language))
    except Exception as e:
        logging.error(f"Error fetching crypto detail for {symbol}: {e}")
        flash('Unable to fetch cryptocurrency details at the moment.', 'error')
        return redirect(url_for('crypto'))

@app.route('/manager')
@login_required
def manager():
    return render_template('manager.html', translations=get_translations(current_user.language))

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    form = SettingsForm()
    
    if request.method == 'GET':
        form.language.data = current_user.language
        form.theme.data = current_user.theme
        form.crypto_wallet.data = current_user.crypto_wallet
    
    if form.validate_on_submit():
        current_user.language = form.language.data
        current_user.theme = form.theme.data
        current_user.crypto_wallet = form.crypto_wallet.data
        db.session.commit()
        
        session['language'] = current_user.language
        session['theme'] = current_user.theme
        
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('settings'))
    
    card = VirtualCard.query.filter_by(user_id=current_user.id).first()
    
    return render_template('settings.html', 
                         form=form, 
                         card=card,
                         translations=get_translations(current_user.language))

@app.route('/admin')
@login_required
def admin():
    if not current_user.is_admin:
        flash('Access denied. Admin privileges required.', 'error')
        return redirect(url_for('dashboard'))
    
    users = User.query.all()
    cards = VirtualCard.query.all()
    messages = SupportMessage.query.filter_by(is_resolved=False).all()
    
    add_funds_form = AdminAddFundsForm()
    block_form = AdminBlockCardForm()
    unblock_form = AdminUnblockCardForm()
    
    return render_template('admin.html', 
                         users=users, 
                         cards=cards, 
                         messages=messages,
                         add_funds_form=add_funds_form,
                         block_form=block_form,
                         unblock_form=unblock_form,
                         translations=get_translations(current_user.language))

@app.route('/admin/add_funds', methods=['POST'])
@login_required
def admin_add_funds():
    if not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    form = AdminAddFundsForm()
    if form.validate_on_submit():
        card = VirtualCard.query.filter_by(card_number=form.card_number.data).first()
        if card:
            card.balance += form.amount.data
            
            # Create transaction record
            transaction = Transaction(
                card_id=card.id,
                amount=form.amount.data,
                transaction_type='deposit',
                description=form.description.data or 'Admin deposit',
                admin_id=current_user.id
            )
            db.session.add(transaction)
            db.session.commit()
            
            flash(f'Successfully added ${form.amount.data} to card {form.card_number.data}', 'success')
        else:
            flash('Card not found', 'error')
    
    return redirect(url_for('admin'))

@app.route('/admin/block_card', methods=['POST'])
@login_required
def admin_block_card():
    if not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    form = AdminBlockCardForm()
    if form.validate_on_submit():
        card = VirtualCard.query.filter_by(card_number=form.card_number.data).first()
        if card:
            card.is_blocked = True
            db.session.commit()
            flash(f'Card {form.card_number.data} has been blocked', 'success')
        else:
            flash('Card not found', 'error')
    
    return redirect(url_for('admin'))

@app.route('/admin/unblock_card', methods=['POST'])
@login_required
def admin_unblock_card():
    if not current_user.is_admin:
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    form = AdminUnblockCardForm()
    if form.validate_on_submit():
        card = VirtualCard.query.filter_by(card_number=form.card_number.data).first()
        if card:
            card.is_blocked = False
            db.session.commit()
            flash(f'Card {form.card_number.data} has been unblocked', 'success')
        else:
            flash('Card not found', 'error')
    
    return redirect(url_for('admin'))

@app.route('/support', methods=['GET', 'POST'])
@login_required
def support():
    form = SupportForm()
    if form.validate_on_submit():
        message = SupportMessage(
            user_id=current_user.id,
            message=form.message.data
        )
        db.session.add(message)
        db.session.commit()
        flash('Your message has been sent to support.', 'success')
        return redirect(url_for('support'))
    
    user_messages = SupportMessage.query.filter_by(user_id=current_user.id).order_by(SupportMessage.created_at.desc()).all()
    
    return render_template('support.html', 
                         form=form, 
                         messages=user_messages,
                         translations=get_translations(current_user.language))

@app.route('/faq')
def faq():
    return render_template('faq.html', translations=get_translations(session.get('language', 'ru')))

@app.route('/privacy')
def privacy():
    return render_template('privacy.html', translations=get_translations(session.get('language', 'ru')))

@app.route('/terms')
def terms():
    return render_template('terms.html', translations=get_translations(session.get('language', 'ru')))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/set_language/<language>')
def set_language(language):
    if language in ['ru', 'en']:
        session['language'] = language
        if current_user.is_authenticated:
            current_user.language = language
            db.session.commit()
    return redirect(request.referrer or url_for('index'))
