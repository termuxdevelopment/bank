def get_translations(language='ru'):
    """Get translations for the specified language"""
    
    translations = {
        'ru': {
            # Navigation
            'virtual_card': 'ВИРТУАЛЬНАЯ КАРТА',
            'home': 'Главная',
            'crypto': 'Криптовалюта',
            'manager': 'Менеджер',
            'settings': 'Настройки',
            'admin_panel': 'Админ Панель',
            'support': 'Поддержка',
            'logout': 'Выход',
            
            # Home/Index
            'welcome': 'Добро пожаловать в UnionBank',
            'slogan': 'Без бумаг и документов, простая регистрация и простая оплата любых услуг по всему миру',
            'get_started': 'Начать',
            'login': 'Войти',
            'register': 'Регистрация',
            
            # Dashboard
            'balance': 'Баланс',
            'card_number': 'Номер карты',
            'cvv': 'CVV',
            'expires': 'Истекает',
            'recent_transactions': 'Последние транзакции',
            'no_transactions': 'Нет транзакций',
            'blocked_card': 'Карта заблокирована',
            
            # Forms
            'username': 'Имя пользователя',
            'email': 'Email',
            'password': 'Пароль',
            'repeat_password': 'Повторите пароль',
            'sign_in': 'Войти',
            'amount': 'Сумма',
            'description': 'Описание',
            'message': 'Сообщение',
            'send': 'Отправить',
            'save': 'Сохранить',
            
            # Settings
            'language': 'Язык',
            'theme': 'Тема',
            'russian': 'Русский',
            'english': 'Английский',
            'light_blue': 'Светло-синий',
            'dark_blue': 'Темно-синий',
            'crypto_wallet': 'Криптокошелек',
            'account_info': 'Информация об аккаунте',
            'virtual_wallet_number': 'Номер виртуального кошелька',
            'account_number': 'Номер аккаунта',
            
            # Crypto
            'price': 'Цена',
            'change_24h': 'Изменение 24ч',
            'buy': 'Купить',
            'chart': 'График',
            
            # Manager
            'contact_manager': 'Связаться с менеджером',
            'telegram_support': 'Поддержка в Telegram',
            'manager_description': 'Свяжитесь с нашим менеджером для покупки криптовалюты, оплаты услуг и пополнения баланса карты.',
            
            # Admin
            'users_list': 'Список пользователей',
            'cards_list': 'Список карт',
            'add_funds': 'Пополнить баланс',
            'block_card': 'Заблокировать карту',
            'unblock_card': 'Разблокировать карту',
            'support_messages': 'Сообщения поддержки',
            
            # FAQ
            'faq_title': 'Часто задаваемые вопросы',
            'how_it_works': 'Как это работает?',
            'how_it_works_answer': 'Зарегистрируйтесь, получите виртуальную карту и пополните баланс через менеджера. Используйте карту для оплаты любых услуг в интернете.',
            'is_it_safe': 'Это безопасно?',
            'is_it_safe_answer': 'Да, мы используем современные технологии шифрования для защиты ваших данных.',
            'how_to_add_funds': 'Как пополнить баланс?',
            'how_to_add_funds_answer': 'Свяжитесь с нашим менеджером через Telegram для пополнения баланса карты.',
            
            # Footer
            'privacy_policy': 'Политика конфиденциальности',
            'terms_of_service': 'Условия использования',
        },
        
        'en': {
            # Navigation
            'virtual_card': 'VIRTUAL CARD',
            'home': 'Home',
            'crypto': 'Cryptocurrency',
            'manager': 'Manager',
            'settings': 'Settings',
            'admin_panel': 'Admin Panel',
            'support': 'Support',
            'logout': 'Logout',
            
            # Home/Index
            'welcome': 'Welcome to UnionBank',
            'slogan': 'No paperwork, simple registration and easy payment for any services worldwide',
            'get_started': 'Get Started',
            'login': 'Login',
            'register': 'Register',
            
            # Dashboard
            'balance': 'Balance',
            'card_number': 'Card Number',
            'cvv': 'CVV',
            'expires': 'Expires',
            'recent_transactions': 'Recent Transactions',
            'no_transactions': 'No transactions',
            'blocked_card': 'Card is blocked',
            
            # Forms
            'username': 'Username',
            'email': 'Email',
            'password': 'Password',
            'repeat_password': 'Repeat Password',
            'sign_in': 'Sign In',
            'amount': 'Amount',
            'description': 'Description',
            'message': 'Message',
            'send': 'Send',
            'save': 'Save',
            
            # Settings
            'language': 'Language',
            'theme': 'Theme',
            'russian': 'Russian',
            'english': 'English',
            'light_blue': 'Light Blue',
            'dark_blue': 'Dark Blue',
            'crypto_wallet': 'Crypto Wallet',
            'account_info': 'Account Information',
            'virtual_wallet_number': 'Virtual Wallet Number',
            'account_number': 'Account Number',
            
            # Crypto
            'price': 'Price',
            'change_24h': '24h Change',
            'buy': 'Buy',
            'chart': 'Chart',
            
            # Manager
            'contact_manager': 'Contact Manager',
            'telegram_support': 'Telegram Support',
            'manager_description': 'Contact our manager to buy cryptocurrency, pay for services and top up your card balance.',
            
            # Admin
            'users_list': 'Users List',
            'cards_list': 'Cards List',
            'add_funds': 'Add Funds',
            'block_card': 'Block Card',
            'unblock_card': 'Unblock Card',
            'support_messages': 'Support Messages',
            
            # FAQ
            'faq_title': 'Frequently Asked Questions',
            'how_it_works': 'How does it work?',
            'how_it_works_answer': 'Register, get a virtual card and top up balance through our manager. Use the card to pay for any services online.',
            'is_it_safe': 'Is it safe?',
            'is_it_safe_answer': 'Yes, we use modern encryption technologies to protect your data.',
            'how_to_add_funds': 'How to add funds?',
            'how_to_add_funds_answer': 'Contact our manager via Telegram to top up your card balance.',
            
            # Footer
            'privacy_policy': 'Privacy Policy',
            'terms_of_service': 'Terms of Service',
        }
    }
    
    return translations.get(language, translations['ru'])
