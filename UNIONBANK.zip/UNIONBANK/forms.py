from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, FloatField, TextAreaField, SelectField, BooleanField
from wtforms.validators import DataRequired, Email, Length, EqualTo, NumberRange, Optional

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign In')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class AdminAddFundsForm(FlaskForm):
    card_number = StringField('Card Number', validators=[DataRequired()])
    amount = FloatField('Amount', validators=[DataRequired(), NumberRange(min=0.01)])
    description = StringField('Description', validators=[Optional()])
    submit = SubmitField('Add Funds')

class AdminBlockCardForm(FlaskForm):
    card_number = StringField('Card Number', validators=[DataRequired()])
    submit = SubmitField('Block Card')

class AdminUnblockCardForm(FlaskForm):
    card_number = StringField('Card Number', validators=[DataRequired()])
    submit = SubmitField('Unblock Card')

class SettingsForm(FlaskForm):
    language = SelectField('Language', choices=[('ru', 'Russian'), ('en', 'English')])
    theme = SelectField('Theme', choices=[('light', 'Light Blue'), ('dark', 'Dark Blue')])
    crypto_wallet = StringField('Crypto Wallet Address', validators=[Optional()])
    submit = SubmitField('Save Settings')

class SupportForm(FlaskForm):
    message = TextAreaField('Message', validators=[DataRequired(), Length(min=10, max=1000)])
    submit = SubmitField('Send Message')
