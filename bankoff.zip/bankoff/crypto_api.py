import requests
import logging
from datetime import datetime, timedelta

def get_crypto_prices():
    """Get current cryptocurrency prices from CoinGecko API"""
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': 'bitcoin,ethereum,tether,binancecoin,cardano,solana,dogecoin,polygon',
            'vs_currencies': 'usd',
            'include_24hr_change': 'true',
            'include_market_cap': 'true'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Map to more user-friendly format
        crypto_map = {
            'bitcoin': {'name': 'Bitcoin', 'symbol': 'BTC'},
            'ethereum': {'name': 'Ethereum', 'symbol': 'ETH'},
            'tether': {'name': 'Tether', 'symbol': 'USDT'},
            'binancecoin': {'name': 'BNB', 'symbol': 'BNB'},
            'cardano': {'name': 'Cardano', 'symbol': 'ADA'},
            'solana': {'name': 'Solana', 'symbol': 'SOL'},
            'dogecoin': {'name': 'Dogecoin', 'symbol': 'DOGE'},
            'polygon': {'name': 'Polygon', 'symbol': 'MATIC'}
        }
        
        result = []
        for crypto_id, price_data in data.items():
            if crypto_id in crypto_map:
                result.append({
                    'id': crypto_id,
                    'name': crypto_map[crypto_id]['name'],
                    'symbol': crypto_map[crypto_id]['symbol'],
                    'price': price_data['usd'],
                    'change_24h': price_data.get('usd_24h_change', 0),
                    'market_cap': price_data.get('usd_market_cap', 0)
                })
        
        return result
    
    except Exception as e:
        logging.error(f"Error fetching crypto prices: {e}")
        # Return default data if API fails
        return [
            {'id': 'bitcoin', 'name': 'Bitcoin', 'symbol': 'BTC', 'price': 45000, 'change_24h': 2.5, 'market_cap': 850000000000},
            {'id': 'ethereum', 'name': 'Ethereum', 'symbol': 'ETH', 'price': 3000, 'change_24h': -1.2, 'market_cap': 360000000000},
            {'id': 'tether', 'name': 'Tether', 'symbol': 'USDT', 'price': 1.00, 'change_24h': 0.1, 'market_cap': 95000000000}
        ]

def get_crypto_chart_data(symbol):
    """Get historical price data for cryptocurrency chart"""
    try:
        # Map symbols to CoinGecko IDs
        symbol_map = {
            'BTC': 'bitcoin',
            'ETH': 'ethereum', 
            'USDT': 'tether',
            'BNB': 'binancecoin',
            'ADA': 'cardano',
            'SOL': 'solana',
            'DOGE': 'dogecoin',
            'MATIC': 'polygon'
        }
        
        crypto_id = symbol_map.get(symbol.upper())
        if not crypto_id:
            return []
        
        url = f"https://api.coingecko.com/api/v3/coins/{crypto_id}/market_chart"
        params = {
            'vs_currency': 'usd',
            'days': '7',  # Last 7 days
            'interval': 'hourly'
        }
        
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # Format data for Chart.js
        prices = data.get('prices', [])
        chart_data = []
        
        for timestamp, price in prices:
            chart_data.append({
                'x': datetime.fromtimestamp(timestamp / 1000).isoformat(),
                'y': price
            })
        
        return chart_data
    
    except Exception as e:
        logging.error(f"Error fetching crypto chart data: {e}")
        # Return empty data if API fails
        return []
