// UnionBank Cryptocurrency JavaScript Module
class CryptoManager {
    constructor() {
        this.apiEndpoint = '/api/crypto-prices';
        this.updateInterval = 30000; // 30 seconds
        this.charts = new Map();
        this.priceHistory = new Map();
        this.socketConnection = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadCryptoPrices();
        this.startPriceUpdates();
        this.initializeCharts();
    }

    setupEventListeners() {
        // Refresh button
        const refreshBtn = document.querySelector('[onclick="updateCryptoPrices()"]');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadCryptoPrices(true));
        }

        // Period selection buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-period]')) {
                this.handlePeriodChange(e.target);
            }
        });

        // Crypto item clicks
        document.addEventListener('click', (e) => {
            if (e.target.closest('.crypto-item, .crypto-row')) {
                this.handleCryptoItemClick(e.target.closest('.crypto-item, .crypto-row'));
            }
        });

        // Buy buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('[onclick*="buyCrypto"]')) {
                e.preventDefault();
                const symbol = this.extractSymbolFromElement(e.target);
                if (symbol) {
                    this.buyCrypto(symbol);
                }
            }
        });
    }

    async loadCryptoPrices(showNotification = false) {
        try {
            const response = await fetch(this.apiEndpoint);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const cryptos = await response.json();
            this.updatePriceDisplay(cryptos);
            this.updatePriceHistory(cryptos);
            
            if (showNotification) {
                this.showNotification('Prices updated successfully', 'success');
            }
            
            // Update last refresh time
            this.updateLastRefreshTime();
            
        } catch (error) {
            console.error('Failed to load crypto prices:', error);
            this.showNotification('Failed to update prices', 'error');
            this.handlePriceLoadError();
        }
    }

    updatePriceDisplay(cryptos) {
        cryptos.forEach(crypto => {
            this.updateCryptoElement(crypto);
            this.updatePriceChangeIndicator(crypto);
        });
    }

    updateCryptoElement(crypto) {
        // Update price elements
        const priceElements = document.querySelectorAll(`#price-${crypto.symbol}, [data-symbol="${crypto.symbol}"] .price-value`);
        priceElements.forEach(element => {
            const oldPrice = parseFloat(element.textContent.replace(/[$,]/g, ''));
            const newPrice = crypto.price;
            
            element.textContent = this.formatPrice(newPrice);
            
            // Add price change animation
            this.animatePriceChange(element, oldPrice, newPrice);
        });

        // Update change elements
        const changeElements = document.querySelectorAll(`#change-${crypto.symbol}, [data-symbol="${crypto.symbol}"] .price-change`);
        changeElements.forEach(element => {
            const change = crypto.change_24h;
            element.textContent = this.formatChange(change);
            element.className = `price-change ${change > 0 ? 'positive text-success' : 'negative text-danger'}`;
        });

        // Update market cap if exists
        const marketCapElements = document.querySelectorAll(`[data-symbol="${crypto.symbol}"] .market-cap`);
        marketCapElements.forEach(element => {
            if (crypto.market_cap) {
                element.textContent = this.formatMarketCap(crypto.market_cap);
            }
        });
    }

    animatePriceChange(element, oldPrice, newPrice) {
        if (oldPrice && oldPrice !== newPrice) {
            const isIncrease = newPrice > oldPrice;
            element.classList.add('price-updated', isIncrease ? 'price-up' : 'price-down');
            
            setTimeout(() => {
                element.classList.remove('price-updated', 'price-up', 'price-down');
            }, 1500);
        }
    }

    updatePriceChangeIndicator(crypto) {
        const indicators = document.querySelectorAll(`[data-symbol="${crypto.symbol}"] .price-indicator`);
        indicators.forEach(indicator => {
            const change = crypto.change_24h;
            indicator.innerHTML = change > 0 ? 
                '<i class="fas fa-arrow-up text-success"></i>' : 
                '<i class="fas fa-arrow-down text-danger"></i>';
        });
    }

    updatePriceHistory(cryptos) {
        cryptos.forEach(crypto => {
            if (!this.priceHistory.has(crypto.symbol)) {
                this.priceHistory.set(crypto.symbol, []);
            }
            
            const history = this.priceHistory.get(crypto.symbol);
            history.push({
                timestamp: Date.now(),
                price: crypto.price,
                change: crypto.change_24h
            });
            
            // Keep only last 100 data points
            if (history.length > 100) {
                history.shift();
            }
        });
    }

    initializeCharts() {
        const chartElements = document.querySelectorAll('.crypto-chart, #priceChart');
        chartElements.forEach(element => {
            const symbol = element.dataset.symbol || this.extractSymbolFromPage();
            if (symbol) {
                this.createChart(element, symbol);
            }
        });
    }

    createChart(element, symbol) {
        const ctx = element.getContext('2d');
        const data = this.generateChartData(symbol);
        
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: `${symbol} Price`,
                    data: data.values,
                    borderColor: '#6f42c1',
                    backgroundColor: 'rgba(111, 66, 193, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#6f42c1',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#6f42c1',
                        borderWidth: 1,
                        callbacks: {
                            label: (context) => {
                                return `Price: $${context.parsed.y.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#b8b9bf'
                        }
                    },
                    y: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: '#b8b9bf',
                            callback: function(value) {
                                return '$' + value.toFixed(2);
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                },
                elements: {
                    point: {
                        hoverRadius: 8
                    }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
        
        this.charts.set(symbol, chart);
        return chart;
    }

    generateChartData(symbol, period = 7) {
        const labels = [];
        const values = [];
        
        // Use real price history if available
        if (this.priceHistory.has(symbol)) {
            const history = this.priceHistory.get(symbol);
            const recentHistory = history.slice(-period);
            
            recentHistory.forEach(point => {
                const date = new Date(point.timestamp);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                values.push(point.price);
            });
        }
        
        // Generate realistic sample data if no history
        if (labels.length === 0) {
            const basePrice = this.getBasePriceForSymbol(symbol);
            
            for (let i = period - 1; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
                
                // Generate realistic price variations
                const variation = (Math.random() - 0.5) * (basePrice * 0.1);
                const trendFactor = (period - i) / period;
                values.push(basePrice + variation + (trendFactor * basePrice * 0.02));
            }
        }
        
        return { labels, values };
    }

    getBasePriceForSymbol(symbol) {
        const basePrices = {
            'BTC': 45000,
            'ETH': 3000,
            'USDT': 1.00,
            'BNB': 300,
            'ADA': 0.5,
            'SOL': 100,
            'DOGE': 0.08,
            'MATIC': 1.2
        };
        return basePrices[symbol] || 100;
    }

    handlePeriodChange(button) {
        const period = parseInt(button.dataset.period);
        const symbol = this.extractSymbolFromPage();
        
        // Update active button
        button.parentNode.querySelectorAll('.btn').forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Update chart
        if (symbol && this.charts.has(symbol)) {
            this.updateChart(symbol, period);
        }
        
        this.showNotification(`Updating chart for ${period} days...`, 'info');
    }

    updateChart(symbol, period) {
        const chart = this.charts.get(symbol);
        if (!chart) return;
        
        const data = this.generateChartData(symbol, period);
        chart.data.labels = data.labels;
        chart.data.datasets[0].data = data.values;
        chart.update('active');
    }

    buyCrypto(symbol) {
        const telegramUrl = 'https://t.me/unionbank_manager';
        const currentPrice = this.getCurrentPrice(symbol);
        const message = `I want to buy ${symbol}. Current price: $${currentPrice}. Please assist me with the purchase.`;
        const encodedMessage = encodeURIComponent(message);
        
        window.open(`${telegramUrl}?text=${encodedMessage}`, '_blank');
        this.showNotification(`Redirecting to manager for ${symbol} purchase...`, 'info');
        
        // Track purchase intent
        this.trackPurchaseIntent(symbol, currentPrice);
    }

    getCurrentPrice(symbol) {
        const priceElement = document.querySelector(`#price-${symbol}, [data-symbol="${symbol}"] .price-value`);
        if (priceElement) {
            return parseFloat(priceElement.textContent.replace(/[$,]/g, '')) || '0.00';
        }
        return '0.00';
    }

    trackPurchaseIntent(symbol, price) {
        // Analytics tracking for purchase intents
        if (typeof gtag !== 'undefined') {
            gtag('event', 'crypto_purchase_intent', {
                'cryptocurrency': symbol,
                'price': price,
                'timestamp': Date.now()
            });
        }
    }

    startPriceUpdates() {
        // Real-time updates every 30 seconds
        setInterval(() => {
            this.loadCryptoPrices();
        }, this.updateInterval);
        
        // Exponential backoff on errors
        this.setupErrorHandling();
    }

    setupErrorHandling() {
        let errorCount = 0;
        const maxErrors = 5;
        
        const originalLoadPrices = this.loadCryptoPrices.bind(this);
        this.loadCryptoPrices = async function(showNotification = false) {
            try {
                await originalLoadPrices(showNotification);
                errorCount = 0; // Reset on success
            } catch (error) {
                errorCount++;
                if (errorCount >= maxErrors) {
                    this.showNotification('Too many failed attempts. Please refresh the page.', 'error');
                    return;
                }
                
                // Exponential backoff
                const delay = Math.min(1000 * Math.pow(2, errorCount), 30000);
                setTimeout(() => this.loadCryptoPrices(), delay);
            }
        }.bind(this);
    }

    handlePriceLoadError() {
        // Show cached data or placeholder
        const cryptoRows = document.querySelectorAll('.crypto-row');
        cryptoRows.forEach(row => {
            const priceElement = row.querySelector('.price-value');
            if (priceElement && !priceElement.textContent.includes('$')) {
                priceElement.textContent = 'Loading...';
                priceElement.classList.add('text-muted');
            }
        });
    }

    updateLastRefreshTime() {
        const lastUpdateElement = document.getElementById('lastUpdate');
        if (lastUpdateElement) {
            const now = new Date();
            lastUpdateElement.textContent = now.toLocaleTimeString();
        }
    }

    handleCryptoItemClick(element) {
        const symbol = element.dataset.symbol;
        if (symbol) {
            // Add click animation
            element.style.transform = 'scale(0.98)';
            setTimeout(() => {
                element.style.transform = '';
            }, 150);
            
            // Navigate to crypto detail page
            window.location.href = `/crypto/${symbol}`;
        }
    }

    extractSymbolFromElement(element) {
        // Extract symbol from various element types
        const symbolMatch = element.getAttribute('onclick')?.match(/buyCrypto\('(\w+)'\)/);
        return symbolMatch ? symbolMatch[1] : null;
    }

    extractSymbolFromPage() {
        // Extract symbol from URL or page context
        const pathMatch = window.location.pathname.match(/\/crypto\/(\w+)/);
        return pathMatch ? pathMatch[1] : null;
    }

    formatPrice(price) {
        if (price < 0.01) {
            return `$${price.toFixed(6)}`;
        } else if (price < 1) {
            return `$${price.toFixed(4)}`;
        } else {
            return `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        }
    }

    formatChange(change) {
        const sign = change > 0 ? '+' : '';
        return `${sign}${change.toFixed(2)}%`;
    }

    formatMarketCap(marketCap) {
        if (marketCap >= 1e12) {
            return `$${(marketCap / 1e12).toFixed(2)}T`;
        } else if (marketCap >= 1e9) {
            return `$${(marketCap / 1e9).toFixed(2)}B`;
        } else if (marketCap >= 1e6) {
            return `$${(marketCap / 1e6).toFixed(2)}M`;
        } else {
            return `$${marketCap.toLocaleString()}`;
        }
    }

    showNotification(message, type = 'info') {
        // Use the global notification system
        if (window.UnionBank && window.UnionBank.showNotification) {
            window.UnionBank.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }

    // Public API methods
    refreshPrices() {
        return this.loadCryptoPrices(true);
    }

    getPriceHistory(symbol) {
        return this.priceHistory.get(symbol) || [];
    }

    getChart(symbol) {
        return this.charts.get(symbol);
    }

    destroy() {
        // Cleanup method
        this.charts.forEach(chart => chart.destroy());
        this.charts.clear();
        this.priceHistory.clear();
        
        if (this.socketConnection) {
            this.socketConnection.close();
        }
    }
}

// Global crypto price update function (legacy support)
window.updateCryptoPrices = function() {
    if (window.cryptoManager) {
        return window.cryptoManager.refreshPrices();
    }
};

window.buyCrypto = function(symbol) {
    if (window.cryptoManager) {
        window.cryptoManager.buyCrypto(symbol);
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize on crypto-related pages
    const isCryptoPage = window.location.pathname.includes('/crypto') || 
                        document.querySelector('.crypto-item, .crypto-row, #priceChart');
    
    if (isCryptoPage) {
        window.cryptoManager = new CryptoManager();
    }
});

// Add CSS animations for price changes
const style = document.createElement('style');
style.textContent = `
    .price-updated {
        transition: all 0.3s ease !important;
    }
    
    .price-up {
        color: #28a745 !important;
        transform: scale(1.05);
    }
    
    .price-down {
        color: #dc3545 !important;
        transform: scale(1.05);
    }
    
    .crypto-item, .crypto-row {
        transition: transform 0.15s ease;
    }
    
    .crypto-item:hover, .crypto-row:hover {
        cursor: pointer;
    }
    
    .loading-shimmer {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: shimmer 1.5s infinite;
    }
    
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    
    .price-indicator {
        display: inline-block;
        margin-left: 0.5rem;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
`;
document.head.appendChild(style);

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CryptoManager;
}
