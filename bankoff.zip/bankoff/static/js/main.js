// UnionBank Main JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeTheme();
    initializeLanguage();
    initializeCryptoUpdates();
    initializeCharts();
    initializeAnimations();
});

// Theme Management
function initializeTheme() {
    const savedTheme = localStorage.getItem('unionbank-theme') || 'dark';
    applyTheme(savedTheme);
    
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

function applyTheme(theme) {
    document.body.className = theme === 'light' ? 'light-theme' : '';
    localStorage.setItem('unionbank-theme', theme);
    
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.textContent = theme === 'light' ? '🌙 Dark' : '☀️ Light';
    }
}

function toggleTheme() {
    const isLight = document.body.classList.contains('light-theme');
    applyTheme(isLight ? 'dark' : 'light');
}

// Language Management
function initializeLanguage() {
    const savedLang = localStorage.getItem('unionbank-language') || 'en';
    applyLanguage(savedLang);
    
    const langSelect = document.getElementById('language-select');
    if (langSelect) {
        langSelect.value = savedLang;
        langSelect.addEventListener('change', function() {
            applyLanguage(this.value);
        });
    }
}

function applyLanguage(lang) {
    localStorage.setItem('unionbank-language', lang);
    // Update text content based on language
    updatePageText(lang);
}

function updatePageText(lang) {
    const translations = {
        en: {
            'welcome': 'Welcome to UnionBank',
            'slogan': 'No paperwork, easy registration, and easy payment for any service worldwide',
            'virtual-card': 'Virtual Card',
            'cryptocurrency': 'Cryptocurrency',
            'settings': 'Settings',
            'logout': 'Logout'
        },
        ru: {
            'welcome': 'Добро пожаловать в UnionBank',
            'slogan': 'Никаких документов, простая регистрация и легкая оплата любых услуг по всему миру',
            'virtual-card': 'Виртуальная карта',
            'cryptocurrency': 'Криптовалюта',
            'settings': 'Настройки',
            'logout': 'Выйти'
        }
    };
    
    const texts = translations[lang];
    if (texts) {
        Object.keys(texts).forEach(key => {
            const elements = document.querySelectorAll(`[data-translate="${key}"]`);
            elements.forEach(el => el.textContent = texts[key]);
        });
    }
}

// Cryptocurrency Updates
function initializeCryptoUpdates() {
    updateCryptoPrices();
    // Update prices every 30 seconds
    setInterval(updateCryptoPrices, 30000);
}

async function updateCryptoPrices() {
    try {
        const response = await fetch('/api/crypto-prices');
        const cryptos = await response.json();
        
        cryptos.forEach(crypto => {
            updateCryptoDisplay(crypto);
        });
    } catch (error) {
        console.error('Failed to update crypto prices:', error);
    }
}

function updateCryptoDisplay(crypto) {
    const priceElement = document.getElementById(`price-${crypto.symbol}`);
    const changeElement = document.getElementById(`change-${crypto.symbol}`);
    
    if (priceElement) {
        priceElement.textContent = `$${crypto.price.toFixed(2)}`;
        
        // Add animation effect
        priceElement.classList.add('price-updated');
        setTimeout(() => priceElement.classList.remove('price-updated'), 1000);
    }
    
    if (changeElement) {
        const change = crypto.change_24h;
        changeElement.textContent = `${change > 0 ? '+' : ''}${change.toFixed(2)}%`;
        changeElement.className = `price-change ${change > 0 ? 'positive' : 'negative'}`;
    }
}

// Chart Initialization
function initializeCharts() {
    const chartElements = document.querySelectorAll('.crypto-chart');
    chartElements.forEach(initializeCryptoChart);
}

function initializeCryptoChart(element) {
    const ctx = element.getContext('2d');
    const symbol = element.dataset.symbol;
    
    // Generate sample data for demonstration
    const data = generateSampleChartData();
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: `${symbol} Price`,
                data: data.values,
                borderColor: '#6f42c1',
                backgroundColor: 'rgba(111, 66, 193, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#6f42c1',
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8b9bf'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: '#b8b9bf'
                    }
                }
            },
            elements: {
                point: {
                    hoverRadius: 8
                }
            }
        }
    });
}

function generateSampleChartData() {
    const labels = [];
    const values = [];
    const basePrice = 45000;
    
    for (let i = 0; i < 24; i++) {
        labels.push(`${i}:00`);
        const variation = (Math.random() - 0.5) * 2000;
        values.push(basePrice + variation);
    }
    
    return { labels, values };
}

// Animations
function initializeAnimations() {
    // Animate cards on scroll
    const cards = document.querySelectorAll('.card');
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const cardObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        cardObserver.observe(card);
    });
    
    // Animate numbers counting up
    animateCounters();
}

function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent);
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            counter.textContent = Math.floor(current);
        }, 50);
    });
}

// Virtual Card Management
function generateCardNumber() {
    const prefix = 'VIRT';
    const middle = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const suffix = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${middle}-${suffix}`;
}

// Copy to clipboard functionality
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showNotification('Copied to clipboard!', 'success');
    }).catch(() => {
        showNotification('Failed to copy', 'error');
    });
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification`;
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(100%)';
    notification.style.transition = 'all 0.3s ease';
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Animate out and remove
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    return isValid;
}

// Real-time balance updates (WebSocket would be better for production)
function updateBalance(cardId, newBalance) {
    const balanceElement = document.getElementById(`balance-${cardId}`);
    if (balanceElement) {
        const oldBalance = parseFloat(balanceElement.textContent.replace('$', ''));
        animateBalanceChange(balanceElement, oldBalance, newBalance);
    }
}

function animateBalanceChange(element, oldValue, newValue) {
    const duration = 1000;
    const steps = 60;
    const stepValue = (newValue - oldValue) / steps;
    let current = oldValue;
    let step = 0;
    
    const timer = setInterval(() => {
        current += stepValue;
        step++;
        
        element.textContent = `$${current.toFixed(2)}`;
        
        if (step >= steps) {
            element.textContent = `$${newValue.toFixed(2)}`;
            clearInterval(timer);
        }
    }, duration / steps);
}

// Map initialization (placeholder for real map)
function initializeMap() {
    const mapContainer = document.getElementById('world-map');
    if (mapContainer) {
        mapContainer.innerHTML = `
            <div class="text-center">
                <i class="fas fa-globe fa-4x mb-3" style="color: var(--primary-color);"></i>
                <h4>UnionBank Global Network</h4>
                <p>Serving customers worldwide with secure virtual banking services</p>
            </div>
        `;
    }
}

// Initialize map when page loads
document.addEventListener('DOMContentLoaded', initializeMap);

// Crypto buy redirect
function buyCrypto(symbol) {
    const telegramUrl = 'https://t.me/unionbank_manager';
    const message = `I want to buy ${symbol}. Please assist me with the purchase.`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`${telegramUrl}?text=${encodedMessage}`, '_blank');
}

// Auto-refresh for admin panel
function initializeAdminPanel() {
    const adminPanel = document.querySelector('.admin-panel');
    if (adminPanel) {
        // Refresh admin data every 30 seconds
        setInterval(refreshAdminData, 30000);
    }
}

async function refreshAdminData() {
    try {
        // This would typically fetch updated data from the server
        console.log('Refreshing admin data...');
    } catch (error) {
        console.error('Failed to refresh admin data:', error);
    }
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Ctrl + / or Cmd + / to open search
    if ((event.ctrlKey || event.metaKey) && event.key === '/') {
        event.preventDefault();
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Escape to close modals
    if (event.key === 'Escape') {
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            const bootstrapModal = bootstrap.Modal.getInstance(modal);
            if (bootstrapModal) {
                bootstrapModal.hide();
            }
        });
    }
});

// Progressive Web App features
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => console.log('SW registered'))
            .catch(error => console.log('SW registration failed'));
    });
}

// Export functions for use in templates
window.UnionBank = {
    copyToClipboard,
    showNotification,
    validateForm,
    buyCrypto,
    toggleTheme,
    applyLanguage
};
