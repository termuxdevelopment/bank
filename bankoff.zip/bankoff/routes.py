from flask import render_template, request, redirect, url_for, flash, session, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db
from models import User, VirtualCard, Transaction, CryptoOrder
from crypto_api import get_crypto_prices, get_crypto_chart_data
from translations import get_translation
from utils import admin_required
import logging

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    # Get crypto prices for display
    crypto_prices = get_crypto_prices()
    return render_template('index.html', crypto_prices=crypto_prices)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'error')
            return render_template('register.html')
        
        # Check if this should be admin (manager account)
        is_admin = username.lower() == 'admin' or email.lower().find('admin') != -1
        
        # Create user
        user = User(username=username, email=email, is_admin=is_admin)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        # Create virtual card for user
        card = VirtualCard(user_id=user.id, card_number=VirtualCard.generate_card_number())
        db.session.add(card)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Login successful!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    card = VirtualCard.query.filter_by(user_id=current_user.id).first()
    recent_transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).limit(5).all()
    crypto_prices = get_crypto_prices()
    
    return render_template('dashboard.html', 
                         card=card, 
                         transactions=recent_transactions, 
                         crypto_prices=crypto_prices)

@app.route('/crypto')
@login_required
def crypto():
    crypto_prices = get_crypto_prices()
    return render_template('crypto.html', crypto_prices=crypto_prices)

@app.route('/crypto/<symbol>')
@login_required
def crypto_detail(symbol):
    chart_data = get_crypto_chart_data(symbol.upper())
    crypto_prices = get_crypto_prices()
    
    # Find the specific crypto data
    crypto_data = None
    for crypto in crypto_prices:
        if crypto['symbol'].upper() == symbol.upper():
            crypto_data = crypto
            break
    
    if not crypto_data:
        flash('Cryptocurrency not found', 'error')
        return redirect(url_for('crypto'))
    
    return render_template('crypto_detail.html', 
                         crypto=crypto_data, 
                         chart_data=chart_data, 
                         symbol=symbol.upper())

@app.route('/buy_crypto', methods=['POST'])
@login_required
def buy_crypto():
    symbol = request.form.get('symbol')
    amount = float(request.form.get('amount', 0))
    price = float(request.form.get('price', 0))
    
    if amount <= 0:
        flash('Invalid amount', 'error')
        return redirect(url_for('crypto_detail', symbol=symbol))
    
    # Create crypto order
    order = CryptoOrder(
        user_id=current_user.id,
        crypto_symbol=symbol,
        amount=amount,
        price_usd=price,
        total_usd=amount * price
    )
    db.session.add(order)
    db.session.commit()
    
    flash(f'Crypto order created for {amount} {symbol}. Manager will contact you via Telegram.', 'success')
    return redirect(url_for('crypto_detail', symbol=symbol))

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        # Update user settings
        current_user.language = request.form.get('language', 'en')
        current_user.theme = request.form.get('theme', 'dark')
        current_user.crypto_wallet = request.form.get('crypto_wallet', '')
        
        db.session.commit()
        flash('Settings updated successfully!', 'success')
    
    return render_template('settings.html')

@app.route('/admin')
@login_required
@admin_required
def admin():
    users = User.query.all()
    cards = VirtualCard.query.all()
    transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(20).all()
    crypto_orders = CryptoOrder.query.order_by(CryptoOrder.created_at.desc()).limit(20).all()
    
    return render_template('admin.html', 
                         users=users, 
                         cards=cards, 
                         transactions=transactions,
                         crypto_orders=crypto_orders)

@app.route('/admin/add_balance', methods=['POST'])
@login_required
@admin_required
def admin_add_balance():
    card_number = request.form.get('card_number')
    amount = float(request.form.get('amount', 0))
    
    card = VirtualCard.query.filter_by(card_number=card_number).first()
    if not card:
        flash('Card not found', 'error')
        return redirect(url_for('admin'))
    
    if amount <= 0:
        flash('Invalid amount', 'error')
        return redirect(url_for('admin'))
    
    # Add balance
    card.balance += amount
    
    # Create transaction record
    transaction = Transaction(
        user_id=card.user_id,
        card_id=card.id,
        amount=amount,
        transaction_type='deposit',
        description=f'Admin deposit: +${amount}',
        status='completed'
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    flash(f'Added ${amount} to card {card_number}', 'success')
    return redirect(url_for('admin'))

@app.route('/admin/block_card', methods=['POST'])
@login_required
@admin_required
def admin_block_card():
    card_number = request.form.get('card_number')
    action = request.form.get('action')
    
    card = VirtualCard.query.filter_by(card_number=card_number).first()
    if not card:
        flash('Card not found', 'error')
        return redirect(url_for('admin'))
    
    if action == 'block':
        card.is_blocked = True
        flash(f'Card {card_number} has been blocked', 'warning')
    elif action == 'unblock':
        card.is_blocked = False
        flash(f'Card {card_number} has been unblocked', 'success')
    
    db.session.commit()
    return redirect(url_for('admin'))

@app.route('/manager')
@login_required
def manager():
    return redirect('https://t.me/unionbank_manager')

@app.route('/privacy')
def privacy():
    return render_template('privacy.html')

@app.route('/terms')
def terms():
    return render_template('terms.html')

@app.route('/faq')
def faq():
    return render_template('faq.html')

# Template context processor for translations
@app.context_processor
def inject_translation():
    def t(key):
        language = 'en'
        if current_user.is_authenticated:
            language = current_user.language
        elif 'language' in session:
            language = session['language']
        return get_translation(key, language)
    
    return dict(t=t)

@app.context_processor
def inject_user_theme():
    theme = 'dark'
    if current_user.is_authenticated:
        theme = current_user.theme
    elif 'theme' in session:
        theme = session['theme']
    
    return dict(user_theme=theme)
